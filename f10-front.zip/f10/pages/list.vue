<template>
  <section class="container">
    <h1 class="title">
      People
    </h1>
    <nuxt-link
      replace
      to="/index"
      class="button--green"
    >
      Back
    </nuxt-link>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>ID</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in list" :key="item.id">
            <td>{{ index }}</td>
            <td>{{ item.id }}</td>
          </tr>
        </tbody>
      </table>
  </section>
</template>

<script>
// import axios from 'axios'

export default {
  async asyncData({ $axios }) {
    const {
      data
    } = await $axios.$get('/service/list')
    return { list: [data] }
  },
  mounted() {
    debugger
  }
}
</script>

<style>
.container {
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.title {
  font-family: 'Quicksand', 'Source Sans Pro', -apple-system, BlinkMacSystemFont,
    'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}
</style>

<template>
  <section class="container">
    <div>
      <h1 class="title">
        People
      </h1>
      <table>
        <thead>
          <tr>
            <th>编号</th>
            <th>人员</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>P001</td>
            <td>Gordie</td>
          </tr>
        </tbody>
      </table>
      <nuxt-link
        replace
        to="/index"
        class="button--green"
      >
        Back
      </nuxt-link>
    </div>
  </section>
</template>

<script>
export default {}
</script>

<style>
.container {
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.title {
  font-family: 'Quicksand', 'Source Sans Pro', -apple-system, BlinkMacSystemFont,
    'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}
</style>

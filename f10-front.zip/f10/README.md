# f10

> F10 Web with Nuxt

## 编译步骤

``` bash
# 安装依赖
$ npm install

# 开发时使用以下命令，会在3000端口启动，访问方式入：localhost:3000
$ npm run dev

# 编译出生产环境用的代码，并且启动服务
$ npm run build
$ npm start

# 预渲染生成静态内容
$ npm run generate
```

## 使用 `docker` 镜像

`npm run build` 或 `npm run generate` 后生成的内容是生产环境可用的内容，可以将这些内容当作简单的静态内容直接放到 `nginx` 中，也可以将这些内容打包成一个 `docker` 镜像。

### 为什么要用 `docker`

本机运行 `nginx` 和容器化对比肯定各有优缺点，本机 `nginx` 自然比 `docker` 容器中的性能稍微好点，但 `docker` 容器化后更利于使用容器编排技术，通过自动横向扩展的方案简化分布式系统部署和维护难度，由于基于 `linux` 的 `cgroups` 和 `LXC`，而并非虚拟机技术。所以一般认为这些性能上的差异都可以忽略。反而容器化后的优势更值得关注。

### 编译 `docker` 镜像

编译 `docker` 镜像需要切换到 `Dockerfile` 所在文件夹，并执行 `docker build` 命令。总体而言 `docker` 镜像的编译非常简单，这里不做详细叙述，仅仅列出所需的命令，并稍作解释。

```bash
docker build -t username/f10:0.0.1 .
```

此命令是为了编译一个名为 `username/f10`, `tag` 为 `0.0.1` 的镜像，通过 `docker push` 命令可将镜像推送到 [Docker Hub](https://hub.docker.com)，但实际生产环境大多会部署自己的镜像服务器来管理编译好的镜像，从而方便运维操作或自动化部署方案的开展。

如果自己的服务器上部署了 `registry`，那么编译镜像时可作如下处理，其中 `localhost` 就是自己部署的镜像服务器的主机名或IP地址：

```bash
docker build -t localhost:5000/f10:0.0.1 .
```

如果之前编译过相同内容的镜像，不需要再次编译，可以直接为镜像加一个新的标签：

```bash
docker tag username/f10:0.0.1 localhost:5000/f10:0.0.1
```

### 登陆到 `docker registry`

一般为了省心会在开发机本地使用 [Docker Desktop](https://www.docker.com/products/docker-desktop) 来运行 `docker` 及 `kubernetes`，此时确保已经在 [Docker Desktop](https://www.docker.com/products/docker-desktop) 中登陆过就行了。如果使用的是其它方式安装的，可以使用 `docker login` 来登陆到 `docker registry` 服务器，如果是自己搭建的服务器，可使用 `docker login localhost:8080` 来登陆。

### 自己搭建 `docker registry`

由于 `docker` 本身容器化的特点，搭建 `docker registry` 也变得十分容易，比起 `npm registry` 的搭建来说基本可以用 “傻瓜式“ 来形容，首先可以去 [registry 的仓库](https://hub.docker.com/_/registry) 看下最新版本，目前查到的是 `2.7.1`，然后按照下面给出的是搭建步骤：

```bash
docker run -d -p 5000:5000 --restart always --name docker-registry registry:2.7.1
```

`docker run` 用于执行 `docker` 镜像，如果需要执行的镜像在本地不存在的话，则会自动从默认的 `registry` 上面拉取。各参数意义如下：

* `-d`：后台运行容器，并返回容器ID
* `-p`：端口映射，将容器端口映射到本机端口
* `5000:5000`：**主机(宿主)端口:容器端口**
* `--restart`：重启策略，这里指定只要有问题就一直重启
* `always`：重启策略的值，只要出错一直重启
* `--name`：指定要创建的容器的名字，后面跟的就是容器名称
* `docker-registry`：运行后的容器的名字，可用于管理容器时使用，通过 `docker ps` 命令可查看到当前运行中的容器，`docker ps -a` 可查看所有已创建的容器
* `registry:2.7.1`：要通过哪个镜像来创建容器，不指定版本就是用 `lasted`，所以最好指定下版本

### 将 `docker` 镜像推送到 [Docker Hub](https://hub.docker.com)

如果需要将编译好的镜像推送到 [Docker Hub](https://hub.docker.com)，仅需要保证编译好的镜像的名字前缀是在 [Docker Hub](https://hub.docker.com) 上注册的用户名即可。然后执行如下命令推送：

```bash
docker push username/f10:0.0.1
```

### 将 `docker` 镜像推送到自己搭建的镜像服务器

```bash
docker push localhost:5000/f10:0.0.1
```

## eslint

`eslint` 可以很好的检查代码质量，但是不利于代码习惯不好的人用，
这里直接在 `nuxt.config.js` 中的 `build` 配置中注释掉了  `eslint-loader` 的配置
如果需要开启 `eslint-loader`，请取消对应注释，注释掉的代码部分如下

```javascript
extend(config, ctx) {
  // Run ESLint on save
  if (ctx.isDev && ctx.isClient) {
    config.module.rules.push({
      enforce: 'pre',
      test: /\.(js|vue)$/,
      loader: 'eslint-loader',
      exclude: /(node_modules)/
    })
  }
}
```

## 路由配置

`nuxt` 会根据 `pages` 目录下面的页面命名规则自动生成路由，也可以在 `nuxt.config.js`中配置
详见文档关于 [路由部分](https://zh.nuxtjs.org/guide/routing)

## 开发时反向代理功能

提供数据的服务器一般跟前端项目是分开部署的，也就不可避免的遇到跨域问题。无论如何处理，允许跨域始终是不够安全的做法。实际生产环境中可能会以 `nginx` 等来做反向代理。除此之外，还需要自己编写相应的插件来完成对 `axios` 的配置。

`axios` 插件 接受三个环境变量来配置服务地址，其中 `SERVICE_BASE_URL` 的优先级最高，会导致忽略 `SERVICE_HOST` 和 `SERVICE_PORT`

* `SERVICE_PORT`：服务的端口号
* `SERVICE_HOST`：服务的主机名或 IP 地址
* `SERVICE_BASE_URL`：服务的地址，包含端口号，甚至可以包含路径
  
根据这些配置，`axios`实际请求的地址应该是 `http://SERVICE_BASE_URL/service` 或 `http://SERVICE_HOST:SERVICE_PORT/service`
要启用 `axios` 插件，需要先在 `modules` 配置中说明要使用 `@nuxtjs/axios` 模块

```javascript
modules: [
  // Doc: https://axios.nuxtjs.org/usage
  '@nuxtjs/axios',
  ...
],
```

然后在 `plugins` 中加入自己编写的 `axios` 插件

```javascript
plugins: ['@/plugins/axios', ...],
```

开发时为了方便，可在 `nuxt.config.js` 中配置代理来取代 `nginx` 的反向代理，需要在 `axios` 节点中配置开启 `proxy`

```javascript
axios: {
  // See https://github.com/nuxt-community/axios-module#options
  proxy: true
},
```

更多问题可查阅文档 [Nuxt.js docs](https://nuxtjs.org).

importScripts('/_nuxt/workbox.4c4f5ca6.js')

workbox.precaching.precacheAndRoute([
  {
    "url": "/_nuxt/2a14fe1c857208a68d5d.js",
    "revision": "f367fca5e06ee2361e62f4d83dfcb7dd"
  },
  {
    "url": "/_nuxt/524d297a36e60ce11c88.js",
    "revision": "e0e80ccb7a575ec1ae0eaeb492ae5163"
  },
  {
    "url": "/_nuxt/c61db117944ecefd6748.js",
    "revision": "a2257ad31d4688f11de6c38f809b0a2c"
  },
  {
    "url": "/_nuxt/cf9c7939e2fb056d6d1f.js",
    "revision": "d7ce43dccf671bb9dcb30c675fd9e447"
  },
  {
    "url": "/_nuxt/db1727292cec82a68b9a.js",
    "revision": "27c2cde4711fc40392020dcb8a2feeda"
  }
], {
  "cacheId": "f10",
  "directoryIndex": "/",
  "cleanUrls": false
})

workbox.clientsClaim()
workbox.skipWaiting()

workbox.routing.registerRoute(new RegExp('/_nuxt/.*'), workbox.strategies.cacheFirst({}), 'GET')

workbox.routing.registerRoute(new RegExp('/.*'), workbox.strategies.networkFirst({}), 'GET')

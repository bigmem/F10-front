import * as axios from 'axios'

const options = {}
if (process.env.SERVICE_BASE_URL) {
  options.baseURL = process.env.SERVICE_BASE_URL
} else {
  const serviceHost = process.env.SERVICE_HOST || 'localhost'
  const servicePort = process.env.SERVICE_PORT || 3000
  options.baseURL = `http://${serviceHost}:${servicePort}/service`
}
// const options = {}
// if (process.server) {
//   options.baseURL = `http://${process.env.SERVICE_HOST || 'localhost'}:${process.env.SERVICE_PORT || 3000}/service`
// }
export default axios.create(options)
